#include "AddRecruitment.h"
#include <iostream>
#include <fstream>
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"
using namespace std;


AddRecruitmentUI::AddRecruitmentUI(vector<Recruitment*>* recruitmentList) {
	this->addRecruitmentController = new AddRecruitment(recruitmentList);
}

void AddRecruitmentUI::addRecruitment(User** user, string task, int headcount, string deadline) {
	this->addRecruitmentController->addRecruitment(user, task, headcount, deadline);
}

AddRecruitment::AddRecruitment(vector<Recruitment*>* recruitmentList) {
	this->recruitmentList = recruitmentList;
}

void AddRecruitment::addRecruitment(User** user, string task, int headcount, string deadline) {
	Recruitment* newRecruitment = new Recruitment(task, headcount, deadline, *user);
	recruitmentList->push_back(newRecruitment);
	(*user)->addRecruitment(newRecruitment);
	
	/*�������*/
	cout << "3.1. ä���������\n";
	cout << "> " << newRecruitment->getTask() << " " << newRecruitment->getHeadCount() << " " << newRecruitment->getDeadLine() << "\n";
}
