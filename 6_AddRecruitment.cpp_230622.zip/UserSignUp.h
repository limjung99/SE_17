#ifndef USER_SIGNUP_H
#define USER_SIGNUP_H
#include "Users.h"
#include <vector>
#include <iostream>

class UserSignUp;

class UserSignUpUI {
private:
	UserSignUp* userSignUp;
public:
	UserSignUpUI(vector<User*>* userList);
	void signUpGeneralUser(string id, string pw, string name, int resiNum);
};

class UserSignUp {
private:
	vector<User*>* userList;
public:
	UserSignUp(vector<User*>* userList);
	void signUpGeneralUser(string id, string pw, string name, int resiNum);
};
#endif // !USER_SIGNUP_H
