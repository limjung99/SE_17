#include "ApplyRecruitment.h"
#include "Recruitment.h"
#include <iostream>
#include <fstream>
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"
using namespace std;
class ApplyRecruitment;

ApplyRecruitmentUI::ApplyRecruitmentUI(vector<User*>* userList) {
	this->applyRecruitmentController = new ApplyRecruitment(userList);
}

void ApplyRecruitmentUI::applyRecruitment(User** user, int busiNum, vector<Recruitment*>* recruitmentList) {
	this->applyRecruitmentController->applyRecruitment(user, busiNum, recruitmentList);
}

ApplyRecruitment::ApplyRecruitment(vector<User*>* userList) {
	this->userList = userList;
}

void ApplyRecruitment::applyRecruitment(User** user, int busiNum, vector<Recruitment*>* recruitmentList) {
	/*�������*/

	for (int i = 0;i < (*recruitmentList).size();i++) {
		User* companyuser = (*recruitmentList)[i]->getUser();
		if (companyuser->getNum() == busiNum) {
			string comName = companyuser->getName();
			int num = companyuser->getNum();
			string task = (*recruitmentList)[i]->getTask();
			cout << "4.2. ä������" << "\n";
			cout << "> " << comName << " " << num << " " << task << "\n";
			(*recruitmentList)[i]->apply(user); /*ä�������� ����� ������ �־���*/
			(*user)->addRecruitment((*recruitmentList)[i]); /*�Ϲݻ���ڿ��� ä�������� �־���*/
		}
	}

}