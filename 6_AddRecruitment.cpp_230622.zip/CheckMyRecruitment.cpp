#include "CheckMyRecruitment.h"
#include "Recruitment.h"
#include <fstream>
#include <iostream>
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"
using namespace std;

CheckMyRecruitmentUI::CheckMyRecruitmentUI(vector<Recruitment*>* recruitmentList) {
	checkMyRecruitmentController = new CheckMyRecruitment(recruitmentList);
}

void CheckMyRecruitmentUI::checkRecruitment(User* user) {
	checkMyRecruitmentController->checkRecruitment(user);
}

CheckMyRecruitment::CheckMyRecruitment(vector<Recruitment*>* recruitmentList) {
	this->recruitmentList = recruitmentList;
}

void CheckMyRecruitment::checkRecruitment(User* user) {
	vector<Recruitment*> myRecruitment = user->getRecruitmentList();
	/*�������*/

	cout << "3.2. ��ϵ� ä�� ������ȸ\n";
	for (int i = 0;i < myRecruitment.size();i++) {
		cout << "> {" << myRecruitment[i]->getTask() << " " << myRecruitment[i]->getHeadCount() << " " << myRecruitment[i]->getDeadLine() << "}\n";
	}

}