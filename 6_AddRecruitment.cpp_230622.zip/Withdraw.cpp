#include "Withdraw.h"
#include <fstream>
#include <iostream>
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"
using namespace std;



WithdrawUI::WithdrawUI(vector<User*>* userList) {
	this->withdraw = new Withdraw(userList);
}

void WithdrawUI::withdrawUser(User* user) {
	this->withdraw->withdrawUser(user);
}

Withdraw::Withdraw(vector<User*>* userList) {
	this->userlist = userList;
}

void Withdraw::withdrawUser(User* user) {
	for (auto it = this->userlist->begin();it != this->userlist->end();++it) {
		User* currentUser = *it;
		if (user->getID() == currentUser->getID()) {
			string tmpID = user->getID();
			delete currentUser;
			this->userlist->erase(it);
			/*�������*/
			cout << "1.2. ȸ��Ż��\n";
			cout << "> " << tmpID << "\n";
			break;
		}
	}
}