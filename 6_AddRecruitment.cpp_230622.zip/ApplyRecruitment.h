#ifndef  APPLY_RECRUITMENT_H
#define  APPLY_RECRUITMENT_H
#include "Users.h"
#include <vector>
using namespace std;

class ApplyRecruitment;

class ApplyRecruitmentUI {
	ApplyRecruitment* applyRecruitmentController;
public:
	ApplyRecruitmentUI(vector<User*>* userList);
	void applyRecruitment(User** user, int busiNum, vector<Recruitment*>* recruitmentList);
};

class ApplyRecruitment {
	vector<User*>* userList;
	CompanyUser* comUser;
public:
	ApplyRecruitment(vector<User*>* userList);
	void applyRecruitment(User** user, int busiNum, vector<Recruitment*>* recruitmentList);
};

#endif // ! APPLY_RECRUITMENT_H
