#include "CheckMyApplication.h"
#include "Recruitment.h"
#include <fstream>
#include <iostream>
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"
using namespace std;

CheckMyApplicationUI::CheckMyApplicationUI(vector<User*>* userList) {
	this->checkMyApplicationController = new CheckMyApplication(userList);
}

vector<Recruitment*> CheckMyApplicationUI::checkMyApplication(User** user) {
	return this->checkMyApplicationController->checkMyApplication(user);
}

CheckMyApplication::CheckMyApplication(vector<User*>* userList) {
	this->userList = userList;
}

vector<Recruitment*> CheckMyApplication::checkMyApplication(User** user) {
	vector<Recruitment*> findRecruitment;
	findRecruitment = (*user)->getRecruitmentList();
	/*�������*/

	cout << "4.3. ����������ȸ" << "\n";
	for (int i = 0;i < findRecruitment.size();i++) {
		string comName = findRecruitment[i]->getUser()->getName();
		int busiNum = findRecruitment[i]->getUser()->getNum();
		string task = findRecruitment[i]->getTask();
		int headcount = findRecruitment[i]->getHeadCount();
		string deadline = findRecruitment[i]->getDeadLine();
		cout << " " << comName << " " << busiNum << " " << task << " " << headcount << " " << deadline << "\n";
	}

	return findRecruitment;
}