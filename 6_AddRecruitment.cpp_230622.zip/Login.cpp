#include "Login.h"
#include <fstream>
#include <iostream>
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"
using namespace std;

LoginUI::LoginUI(vector<User*>* userList) {
	loginController = new Login(userList);
}

void LoginUI::login(string id, string pw, User** user) {
	loginController->login(id, pw, user);
}

Login::Login(vector<User*>* userList) {
	this->userList = userList;
}

void Login::login(string id, string pw, User** user) {
	for (int i = 0;i < this->userList->size();i++) {
		User* currentUser = (*this->userList)[i];
		if (id == currentUser->getID() && pw == currentUser->getPW()) {
			*user = currentUser;
			cout << "2.1. �α���\n";
			cout << "> " << (*user)->getID() << " " << pw << "\n";
			break;
		}
	}
}