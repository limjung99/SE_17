#include "UserSignUp.h"
#include <fstream>
#include <iostream>
using namespace std;
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"

UserSignUpUI::UserSignUpUI(vector<User*>* userList) {
	userSignUp = new UserSignUp(userList);
}

void UserSignUpUI::signUpGeneralUser(string id, string pw, string name, int resiNum) {	
	userSignUp->signUpGeneralUser(id, pw, name, resiNum);
}

UserSignUp::UserSignUp(vector<User*>* userList) {
	
	this->userList = userList;
}

void UserSignUp::signUpGeneralUser(string id, string pw, string name, int resiNum) {
	
	User* newUser = new GeneralUser(id, pw, name, resiNum);
	this->userList->push_back(newUser);
	/*�������*/

	cout << "1.1. ȸ������\n";
	cout << "> 2 " << name << " " << resiNum << " " << id << " " << pw << "\n";

}