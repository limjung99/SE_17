#include "System.h"
#include "Users.h"
#include <iostream>
#include <vector>
#include "UserSignup.h"
#include "CompanySignUp.h"
#include "Withdraw.h"
#include "Login.h"
#include "Logout.h"
#include "AddRecruitment.h"
#include "CheckMyRecruitment.h"
#include "SearchRecruitment.h"
#include "ApplyRecruitment.h"
#include "CheckMyApplication.h"
#include "PrintStastics.h"
#include "CacncleApplication.h"
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"
using namespace std;

void System::run() {
    /*
        �ý��� �������̽� ����
    */
    int menu_level_1;
    int menu_level_2;
    bool exit = false;
    /*
        ȸ���̸����� ä�� �˻��� recruitment table
    */
    vector<Recruitment*> findRecruitment;
    /*
        ȸ������ user ���̺�
    */
    vector<User*> userList;
    /*
        Recruitment ���̺�
    */
    vector<Recruitment*> recruitmentList;
    /*
       UI �ν��Ͻ� ����
    */
    UserSignUpUI userSignUpUI = UserSignUpUI(&userList);
    CompanySignUpUI companySignUpUI = CompanySignUpUI(&userList);
    WithdrawUI withDrawUI = WithdrawUI(&userList);
    LoginUI loginUI = LoginUI(&userList);
    LogoutUI logoutUI = LogoutUI(&userList);
    AddRecruitmentUI addRecruitmentUI = AddRecruitmentUI(&recruitmentList);
    CheckMyRecruitmentUI checkMyRecruitmentUI = CheckMyRecruitmentUI(&recruitmentList);
    /* -------- ok ----------- */
    SearchRecruitmentUI searchRecruitmentUI = SearchRecruitmentUI(&userList);
    ApplyRecruitmentUI applyRecruitmentUI = ApplyRecruitmentUI(&userList);
    CheckMyApplicationUI checkMyApplicationUI = CheckMyApplicationUI(&userList);
    CancleApplicationUI cancleApplicationUI = CancleApplicationUI(&userList);
    PrintStasticsUI printStasticsUI = PrintStasticsUI(&userList);
    /*����������*/
    ifstream inputFile(INPUT_FILE_NAME);
    ofstream outputFile(OUTPUT_FILE_NAME);
    
    while (!exit) {
        string inputline; /*line�� �Է�*/
        getline(inputFile, inputline);
        /*Tokenizing*/
        stringstream sstream(inputline);
        vector<string> words;
        string word;
        while (getline(sstream, word, ' ')) {
            words.push_back(word);
        }

        menu_level_1 = stoi(words[0]);
        menu_level_2 = stoi(words[1]);
        
        switch (menu_level_1)
        {
        case 1:
            switch (menu_level_2)
            {
            case 1:  /* 1 1 ȸ������ */
            {
                int usertype = stoi(words[2]);

                if (usertype == 1) {/* 1 1 1 ����ȸ������ */
                    string name; int resiNum; string id; string pw;
                    name = words[3];
                    resiNum = stoi(words[4]);
                    id = words[5];
                    pw = words[6];
                    userSignUpUI.signUpGeneralUser(id, pw, name, resiNum);
                }
                else { /* 1 1 2 ȸ��ȸ������ */
                    string comName; int busiNum; string id; string pw;
                    comName = words[3];
                    busiNum = stoi(words[4]);
                    id = words[5];
                    pw = words[6];
                    companySignUpUI.signUpCompanyUser(id, pw, comName, busiNum);
                }

                break;
            }
                
            case 2: /* 1 2 ȸ��Ż��*/
            {
                withDrawUI.withdrawUser(this->user);
                break;
            }
            default:
                break;
            }
            break;
        
        case 2:
            switch (menu_level_2)
            {
            case 1: /* 2 1 �α���*/
            {
                string id; string pw;
                id = words[2];
                pw = words[3];
                loginUI.login(id, pw, &user);
                break;
            }
            case 2: /* 2 2 �α׾ƿ�*/
            {
                logoutUI.logout(&user);
                break;
            }
            default:
                break;
            }
            break;
        case 3:
            switch (menu_level_2)
            {
            case 1: /* 3 1 ȸ��ȸ���� ä��������� */
            {
                string task; int headcount; string deadline;
                task = words[2];
                headcount = stoi(words[3]);
                deadline = words[4];
                addRecruitmentUI.addRecruitment(&user, task, headcount, deadline);
                break;
            }
            case 2: /* 3 2 ȸ��ȸ���� ����� ä�� ���� ��ȸ */
            {
                checkMyRecruitmentUI.checkRecruitment(user);
                break;
            }
            default:
                break;
            }
            break;
        case 4:
            switch (menu_level_2)
            {
            case 1: /* 4 1 ä�������˻�*/
            {
                string comName;
                comName = words[2];
                findRecruitment = searchRecruitmentUI.searchRecruitment(&user, comName);
                break;
            }
            case 2: /* 4 2 ä������*/
                int busiNum1;
                busiNum1 = stoi(words[2]);
                applyRecruitmentUI.applyRecruitment(&user, busiNum1, &findRecruitment);
                break;
            case 3: /* 4 3 ����������ȸ*/
                findRecruitment = checkMyApplicationUI.checkMyApplication(&user);
                break;
            case 4: /* 4 4 �������*/
                int busiNum2;
                busiNum2 = stoi(words[2]);
                cancleApplicationUI.cancleApplication(findRecruitment, busiNum2, &user);
                break;
            default:
                break;
            }
            break;

        case 5:
            switch (menu_level_2)
            {
            case 1: /* 5 1 �����������*/
                printStasticsUI.printStastics(&user);
                break;
            default:
                break;
            }
            break;
        case 6: /* 6 ���� */
            exit = true;
            break;
        default:
            break;
        }
    }

}