#include <iostream>
#include "System.h"

int main() {
	System mysystem = System();
	mysystem.run();
	return 0;
}