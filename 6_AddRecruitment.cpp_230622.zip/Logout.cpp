#include "Logout.h"
#include <fstream>
#include <iostream>
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"
using namespace std;

LogoutUI::LogoutUI(vector<User*>* userList) {
	logoutController = new Logout(userList);
}

void LogoutUI::logout(User** user) {
	this->logoutController->logout(user);
}

Logout::Logout(vector<User*>* userList) {
	this->userList = userList;
}

void Logout::logout(User** user) {
	/*�������*/

	cout << "2.2. �α׾ƿ�\n";
	cout << "> " << (*user)->getID() <<  "\n";

	*user = nullptr;
}