#include "PrintStastics.h"
#include "Recruitment.h"
#include <fstream>
#include <iostream>
#define MAX_STRING 32
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"
using namespace std;

PrintStasticsUI::PrintStasticsUI(vector<User*>* userList) {
	this->printStasticsConroller = new PrintStastics(userList);
}

void PrintStasticsUI::printStastics(User** user) {
	printStasticsConroller->printStastics(user);
}

PrintStastics::PrintStastics(vector<User*>* userList) {
	this->userList = userList;
}

void PrintStastics::printStastics(User** user) {
	vector<Recruitment*> recruitmentList;
	recruitmentList = (*user)->getRecruitmentList();
	/*�������*/

	cout << "5.1. ���� ���� ���" << "\n";
	for (int i = 0;i < recruitmentList.size();i++) {
		cout << "> " << recruitmentList[i]->getTask() << " " << recruitmentList[i]->getNumApplicant() << "\n";
	}

}